# CS3270 - AUSTRALIAN WEATHER

This is a Python library Containing my work for CS3270

## Installation

Use the package manager [pip] to install australian_weather_sa

```bash
pip install setuptools wheel
python setup.py sdist bdist_wheel

pip install weather
```


### Module 1

#### FUNCTIONS
    add_to_weather_data(content)
        Adds each line of the input to the variable called "data"
        :param content:
        :return:

    load_csv(file_name)
        Loads the csv data from the file and passes it to the function "add_to_weather_data()"
        :param file_name:
        :return:

    load_csv_pandas(file_name)
        Creates a pandas dataframe from the inputted csv file and returns it
        :param file_name:
        :return:

#### VARIABLES
    data = []

